package com.capgemini.fake;

import java.util.List;

public interface IDao {
	public Cart updateCart(Integer productId, String emailId);
	public void removeItemFromTheCart(Integer cartId);
	public List<Cart> cartDetails(String emailId);
}
